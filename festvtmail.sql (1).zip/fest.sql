-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2018 at 04:32 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fest`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `name` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pass` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`name`, `email`, `pass`) VALUES
('Ajay Chiller', 'ajay22gu@gmail.com', 'admin'),
('Om Kar', 'omkar@gmial.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `applied`
--

CREATE TABLE `applied` (
  `usn` varchar(20) NOT NULL,
  `eid` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applied`
--

INSERT INTO `applied` (`usn`, `eid`) VALUES
('007', 103),
('007', 104),
('007', 107),
('007', 108),
('007', 112),
('007', 116),
('1400', 101),
('1400', 103),
('1410', 108),
('14420', 103),
('14420', 104),
('14420', 116),
('1455', 103),
('1455', 107),
('1455', 112);

-- --------------------------------------------------------

--
-- Table structure for table `coordinator`
--

CREATE TABLE `coordinator` (
  `cname` varchar(20) DEFAULT NULL,
  `cid` int(10) NOT NULL,
  `pass` varchar(20) NOT NULL DEFAULT 'co123',
  `did` int(10) DEFAULT NULL,
  `phno` bigint(15) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `eventid` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coordinator`
--

INSERT INTO `coordinator` (`cname`, `cid`, `pass`, `did`, `phno`, `email`, `eventid`) VALUES
('OmKar', 14001, 'co123', 1002, 75563541, 'omkar@gmail.com', 101),
('Shiva', 14220, 'co123', 1002, 85542138, 'shiva@gmail.com', 112),
('Akash', 140005, 'co123', 1002, 776054955, 'akash@gmail.com', 103),
('Raja', 15001, 'co123', 1001, 9345535658, 'raj@gmail.com', 104),
('tony', 16001, 'co123', 1005, 6595857545, 'tony@gmail.com', 107),
('danush', 1701, 'co123', 1003, 7795857545, 'danush@gmail.com', 108),
('333333', 33333, 'co123', 1002, 333, '33', 333),
('Vidhya', 14028, 'co123', 1006, 882241158, 'vidhya@gmail.com', 109),
('Dinesha', 14026, 'co123', 1001, 857424555, 'dinu@gmail.com', 116),
('Ajay', 14025, 'co123', 1001, 8553102457, 'ajay22gu@gmail.com', 125);

-- --------------------------------------------------------

--
-- Table structure for table `dept`
--

CREATE TABLE `dept` (
  `dname` varchar(20) DEFAULT NULL,
  `did` int(10) NOT NULL,
  `pass` varchar(20) NOT NULL DEFAULT 'dedpt123'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dept`
--

INSERT INTO `dept` (`dname`, `did`, `pass`) VALUES
('ME', 1001, 'dedpt123'),
('CSE', 1002, 'dedpt123'),
('CV', 1003, 'dedpt123'),
('EC', 1004, 'dedpt123'),
('EEE', 1005, 'dedpt123'),
('Sports', 1006, 'dedpt123'),
('Architecture', 1007, 'dedpt123'),
('cultural', 10088, 'cul123'),
('waste', 1, 'dept123');

-- --------------------------------------------------------

--
-- Table structure for table `eventt`
--

CREATE TABLE `eventt` (
  `name` varchar(20) DEFAULT NULL,
  `eid` int(10) NOT NULL,
  `descp` varchar(50) DEFAULT NULL,
  `cid` int(10) DEFAULT NULL,
  `did` int(10) DEFAULT NULL,
  `loc` varchar(20) DEFAULT NULL,
  `stime` time DEFAULT NULL,
  `etime` time DEFAULT NULL,
  `fee` int(10) DEFAULT NULL,
  `noapplied` int(10) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `eventt`
--

INSERT INTO `eventt` (`name`, `eid`, `descp`, `cid`, `did`, `loc`, `stime`, `etime`, `fee`, `noapplied`) VALUES
('Logomania', 103, 'identify the logos', 140005, 1002, 'mech block 11', '18:00:00', '19:01:00', 250, 0),
('Coding', 101, 'Coding and Testing', 14001, 1002, 'PG Block ', '09:00:00', '12:00:00', 50, 0),
('TurtleJam', 112, 'Dance Competition\r\n', 14220, 1002, 'Indoor Stadium', '17:00:00', '20:00:00', 500, 0),
('craftting', 104, 'making useful things from the waste provided', 15001, 1001, 'Library lawn', '05:00:00', '07:30:00', 500, 0),
('Shock', 107, 'Find the fault in circuit', 16001, 1005, 'EC block', '12:00:00', '14:00:00', 50, 0),
('build', 108, 'Apartment modeling', 1701, 1003, 'CivilBlock', '15:00:00', '20:00:00', 70, 0),
('RoboWar', 116, 'Robot Wars', 14026, 1001, 'Mech Block', '05:00:00', '07:00:00', 500, 0),
('Counter Strike', 125, 'Counter Strike PC game', 14025, 1001, 'CSE LAB', '08:00:00', '09:00:00', 250, 0);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `name` varchar(20) DEFAULT NULL,
  `usn` varchar(20) NOT NULL,
  `pass` varchar(20) DEFAULT NULL,
  `phno` bigint(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `clg` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`name`, `usn`, `pass`, `phno`, `email`, `clg`) VALUES
('none', '0', 'none', 0, 'none', 'none'),
('Arjun ', '1455', 'arj123', 8553105483, 'arjun22gu@gmail.com', 'NewHorizon'),
('Abhi', '1524', 'abi123', 855420886, ' abi@gmail.com', 'BMSCE'),
('usha', '1666', 'usha123', 975420886, ' usha@gmail.com', 'NewHorizon'),
('shashank', '428', 'sah123', 785420886, 'shash@gmail.com', 'NewHorizon'),
('harisha', '885', 'hari123', 995420886, 'hari@gmail.com', 'NewHorizon'),
('Chethu', '999', 'chethu123', 9365862456, 'chethu@gmail.com', 'BMSCE'),
('tonysatrk', '007', 'tony123', 8889945888, 'tony@gmail.com', 'BMSCE'),
('Vidhya', '143', 'vudhya', 9740243436, ' vidhya@gmail.com', 'NH'),
('Sneha', '2222', 'SNEHA', 855412484, 'SNEHA@gmail.com', 'cmr'),
('Sumaya', '489', 'sumaya', 7762548544, 'sumaya@gmail.com', 'mountCaremel'),
('OmKAR', '14420', 'om123', 9740243454, 'omkar.july19@gmail.com', 'BMSCE'),
('Ajay Chiller', '1400', 'ajay123', 8553105483, 'ajay22gu@gmail.com', 'BMSCE');

-- --------------------------------------------------------

--
-- Table structure for table `win`
--

CREATE TABLE `win` (
  `eid` int(10) NOT NULL,
  `place` varchar(20) NOT NULL,
  `price` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `win`
--

INSERT INTO `win` (`eid`, `place`, `price`) VALUES
(333, 'third', 4),
(333, 'second', 4),
(333, 'first', 4),
(101, 'first', 1000),
(101, 'second', 700),
(101, 'third', 500),
(11111, 'first', 2),
(11111, 'second', 2),
(11111, 'third', 2),
(112, 'first', 5000),
(112, 'second', 2500),
(112, 'third', 1000),
(103, 'first', 2000),
(103, 'second', 1000),
(103, 'third', 500),
(104, 'first', 10000),
(104, 'second', 5000),
(104, 'third', 1000),
(107, 'first', 500),
(107, 'second', 200),
(107, 'third', 100),
(108, 'first', 500),
(108, 'second', 200),
(108, 'third', 100),
(2, 'first', 2),
(2, 'second', 2),
(2, 'third', 2),
(109, 'first', 5000),
(109, 'second', 2500),
(109, 'third', 2000),
(115, 'first', 5000),
(115, 'second', 2500),
(115, 'third', 1000),
(116, 'first', 5000),
(116, 'second', 2500),
(116, 'third', 1000),
(125, 'third', 300),
(125, 'second', 500),
(125, 'first', 1000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applied`
--
ALTER TABLE `applied`
  ADD PRIMARY KEY (`usn`,`eid`),
  ADD KEY `eid` (`eid`);

--
-- Indexes for table `coordinator`
--
ALTER TABLE `coordinator`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `did` (`did`),
  ADD KEY `eventid` (`eventid`);

--
-- Indexes for table `dept`
--
ALTER TABLE `dept`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `eventt`
--
ALTER TABLE `eventt`
  ADD PRIMARY KEY (`eid`),
  ADD KEY `cid` (`cid`),
  ADD KEY `did` (`did`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`usn`);

--
-- Indexes for table `win`
--
ALTER TABLE `win`
  ADD PRIMARY KEY (`eid`,`place`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
